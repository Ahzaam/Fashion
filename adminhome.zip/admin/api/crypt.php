<?php
$ciphering = "AES-128-CBC";
$options = 0;
$encryption_iv = "1234567890123456"; // encryption_iv
// $key = "ahzaam1233secure"; // key
$remstr = "ahzaam1233secure";


 ?>
